export declare class FlexLayoutServerModule {
}
